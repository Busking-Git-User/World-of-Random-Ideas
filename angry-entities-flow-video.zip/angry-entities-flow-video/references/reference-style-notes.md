# Reference style notes (from the Water vs Cola reference video)

This file records what the uploaded reference shows, so actions and dialogue stay in the same world. Edit it if you upload a new reference.

## Framing
- 9:16, medium eye-level shot, two characters side by side filling the frame, the left character slightly cropped at the left edge.
- Whole bodies visible down to the white sneaker feet standing on a silver wire shelf.
- Blurred snack packs on shelves in the background, shallow depth of field, condensation droplets on both characters.

## Faces
- Huge round white eyes, black pupils, thick black eyebrows, strong colored eyelid shading (blue on Water).
- Expressions used: angry brows with open shouting mouth, smug closed-mouth smile, wide toothy grin, side-eye looking away, flat unimpressed mouth.

## Actions used (reuse these, do not invent big new ones)
- Pointing a gloved finger at the other character.
- Glove on hip or arm held across the body.
- Glove touching the head or temple while thinking or bragging.
- Leaning toward the other character while shouting.
- Silver 3D comic spikes at the frame edges only while someone shouts.
- Characters stay on the shelf. No walking away, no costume changes, no props appear in the characters' hands.
- A customer's hand entering from above is the only outside element allowed, and only for an ending.

## Dialogue feel
- Short, direct, sassy comebacks in everyday Tagalog.
- Each line hits a real flaw or brags about a real strength of the other (water is healthy but plain, cola is tasty but sugary).
- No narration, no long speeches.
