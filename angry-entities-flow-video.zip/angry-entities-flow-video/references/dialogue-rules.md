# Dialogue rules

Lines must make sense as one real argument. The reference video works because each line answers the one before it and rests on something true about the entity (Water: healthy but plain; Cola: tasty but full of sugar). Copy that logic.

## The chain

1. **Insult** from A about a real flaw of B.
2. **Comeback** from B: either a real flaw of A, or the same insult turned back on A.
3. **Brag** from A about a real strength.
4. **Counter** from B: a true downside of that strength.
5. **Punchline** at the end of the last clip: a reversal, a third entity entering, or a hand picking one of them, so the ending proves one side's point.

With 3 clips of 2 lines each there are 6 lines: insult, comeback, brag, counter, protest, punchline.

## Rules

- Every line replies directly to the previous line. Reuse a keyword from it when you can.
- Use only strengths and flaws listed in `data/entities.json`, or add new true ones there first.
- No random topics. Do not bring in a new subject unless a third entity or the ending brings it in.
- Each entity keeps one personality. Kape is smug, Tsokolate is dramatic, Sachet is scrappy.
- The ending must be understandable without captions: show it in the action (a hand reaching in, a sachet sliding in) and say it in one short line.
- Name the other character at most once per clip.

## Flow-friendly wording

- Max 9 words per line, 2 lines per clip.
- Plain everyday Tagalog. Avoid slang that is hard to pronounce, idioms with double meanings, and long compound words.
- Spell numbers out (sampung piso, dalawandaan).
- Use simple punctuation: periods, commas, a single question mark or exclamation mark.
- No ALL CAPS, no ellipses, no "?!", no emojis, no double quotes inside a line.
- Put the speaker's tone in the episode file's `tone` field (mocking, offended, proud, smug), not in the line itself.

## Cultural hooks that work

Lunes at deadline, sahod, opisina, boss, ulan, Pasko, Noche Buena, handaan, sari-sari store, sampung piso, puyat, eyebags, diet.

## Before and after

Random: "Ang tamis mo. Puro asukal ka lang." then "Ang pait mo. Nakakakaba ka pa." The second line is not a believable comeback for a hot chocolate.

Logical: Kape says "Pambata ka lang, Tsokolate." Tsokolate says "Ikaw nga, nilalagyan pa ng asukal." Her reply uses a true flaw of Kape (people add sugar to him) and answers the insult directly.
