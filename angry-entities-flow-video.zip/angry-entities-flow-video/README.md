# angry-entities-flow-video

A Claude skill that writes 9:16 "arguing entities" videos for Google Flow (Veo). Talking products or foods argue in meaningful Tagalog. Each clip gets an image prompt and an 8-second video prompt, and every video prompt ends with a block that stops Flow from giving a line to the wrong character.

## What it does

- Keeps one locked visual style, taken from the Water vs Cola reference video: glossy 3D CGI, water droplets, black noodle arms, white gloves, white sneaker feet, silver comic spikes on shouted lines.
- Locks the characters to your uploaded reference image: appearance never changes, and actions and dialogue stay within what the reference shows.
- Writes dialogue as a real back-and-forth argument built on true strengths and flaws of each entity.
- Labels every line with its speaker, side of the frame and voice.
- Produces no captions, subtitles or on-screen text.
- Produces one keyframe image prompt per clip, plus one 8-second video prompt per clip.

## Folder layout

```
angry-entities-flow-video/
├── SKILL.md                      instructions Claude follows
├── README.md                     this file
├── data/
│   ├── style_lock.txt            locked style (edit only to change the look)
│   ├── rig.txt                   shared character rig
│   ├── default_setting.txt       default background
│   ├── spikes.txt                shout effect
│   ├── reference_lock.txt        reference image lock used in every prompt
│   ├── closing_block.txt         anti-error block at the end of every video prompt
│   └── entities.json             looks, voices, strengths, flaws
├── references/
│   ├── dialogue-rules.md         how to write lines that make sense
│   ├── reference-style-notes.md  what the reference shows (framing, actions, feel)
│   ├── example-episode.json      sample input
│   └── example-output.md         sample generated prompts
└── scripts/
    └── build_prompts.py          builds prompts and checks the dialogue
```

## Edit it

- **Add an entity:** copy `_new_entity_template` in `data/entities.json`, rename it, and fill it in. Keep `look` to one sentence.
- **Change a voice:** edit the entity's `voice` field. The change appears in every prompt.
- **Change the look:** edit `data/style_lock.txt` and `data/rig.txt`. Everything is rebuilt from them.
- **New reference image:** update `references/reference-style-notes.md` and the entity `look` fields, and set `reference_notes` in your episode file.
- **Change the anti-error wording:** edit `data/closing_block.txt`. Keep the `{placeholders}`.
- **Change the dialogue rules:** edit `references/dialogue-rules.md`.

## Run the builder yourself

Python 3, no packages needed.

```bash
python scripts/build_prompts.py references/example-episode.json
python scripts/build_prompts.py my-episode.json -o my-episode-prompts.md
```

The script prints warnings for lines that are too long, use ?! or ALL CAPS, contain digits, or have an unknown speaker.

## Put it on GitHub

```bash
cd angry-entities-flow-video
git init
git add .
git commit -m "Add angry-entities-flow-video skill"
git branch -M main
git remote add origin https://github.com/<your-username>/angry-entities-flow-video.git
git push -u origin main
```

## Use it in Claude

Upload the `.skill` or `.zip` file in Claude's skills settings, or save it from the file card when Claude shows it, if your plan allows custom skills. Then ask for example: "Kape vs tsokolate, 3 scripts, 9:16, for Google Flow."

## Use the output in Flow

1. Attach your reference image as the style and character reference in every clip.
2. Generate each clip's keyframe image and use it as that clip's first frame.
3. In Flow, use Frames to Video: the keyframe image starts each clip, and each clip's last frame starts the next.
4. Generate one clip at a time and check who speaks each line. If a line lands on the wrong character, regenerate the clip.
