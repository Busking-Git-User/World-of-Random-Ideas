#!/usr/bin/env python3
"""Build Google Flow (Veo) image + video prompts from an episode file.

Usage:
    python scripts/build_prompts.py episode.json            # prints markdown
    python scripts/build_prompts.py episode.json -o out.md  # writes a file

Everything the prompts say about style, characters, voices and the closing
anti-error block comes from the files in ../data, so edit those files (not this
script) to change the look. Standard library only.
"""
import argparse
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"
SIDES = ["left", "right"]
TIMES = {1: [0.5], 2: [0.5, 4.0], 3: [0.5, 3.0, 5.5]}
MAX_WORDS = 9


def read(name):
    return (DATA / name).read_text(encoding="utf-8").strip()


def load_entities():
    raw = json.loads(read("entities.json"))
    return {k: v for k, v in raw.items() if not k.startswith("_")}


def check_line(text, clip_no, line_no):
    """Return a list of warnings for one dialogue line."""
    w = []
    where = f"clip {clip_no} line {line_no}"
    if len(text.split()) > MAX_WORDS:
        w.append(f"{where}: more than {MAX_WORDS} words, may be cut off in 8 seconds")
    if re.search(r"[?!]{2,}", text):
        w.append(f"{where}: avoid combined punctuation like ?! or !!")
    if "..." in text or "\u2026" in text:
        w.append(f"{where}: avoid ellipses")
    if re.search(r"\d", text):
        w.append(f"{where}: spell numbers out as words")
    if '"' in text:
        w.append(f"{where}: remove double quotes inside the line")
    if any(len(t) > 1 and t.isupper() for t in re.findall(r"[A-Za-z]+", text)):
        w.append(f"{where}: avoid ALL CAPS words")
    return w


def pos_for(key, main, extras):
    if key in main:
        return SIDES[main.index(key)]
    return "center front"


def build_clip(ep, ents, clip, idx, warnings):
    main = ep["entities"]
    present = list(main) + [e for e in clip.get("extra_present", []) if e not in main]
    language = ep.get("language", "Tagalog")
    setting = ep.get("setting") or read("default_setting.txt")
    style = read("style_lock.txt").format(setting=setting)
    rig = read("rig.txt")
    lines = clip["lines"]
    n = len(lines)
    if n not in TIMES:
        sys.exit(f"clip {idx}: use 1 to 3 lines per 8-second clip (found {n})")
    times = TIMES[n]

    for key in present:
        if key not in ents:
            sys.exit(f"Unknown entity '{key}'. Add it to data/entities.json first.")
    for j, ln in enumerate(lines, 1):
        if ln["who"] not in present:
            sys.exit(f"clip {idx} line {j}: speaker '{ln['who']}' is not in this clip")
        warnings.extend(check_line(ln["say"], idx, j))
    for a, b in zip(lines, lines[1:]):
        if a["who"] == b["who"]:
            warnings.append(f"clip {idx}: same speaker twice in a row, make sure it is intended")

    def label(key):
        e = ents[key]
        return f"{e['name']} on the {pos_for(key, main, [])}"

    chars = " ".join(f"{label(k)}: {ents[k]['look']}, {ents[k]['voice']}." for k in present)

    # ---------- image prompt ----------
    poses = clip.get("poses", {})
    for k in present:
        if k not in poses:
            sys.exit(f"clip {idx}: add a 'poses' entry for '{k}' (used for the keyframe image)")
    first = lines[0]["who"]
    pose_text = " ".join(
        f"{ents[k]['name']} on the {pos_for(k, main, [])}: {ents[k]['look']}. Pose and expression: {poses[k]}."
        for k in present
    )
    spikes = " " + read("spikes.txt") if clip.get("spikes") else ""
    ref_lock = read("reference_lock.txt")
    if ep.get("reference_notes"):
        ref_lock += f" Reference details: {ep['reference_notes']}"
    image_prompt = (
        f"Single still frame, vertical 9:16, match the style reference image exactly. {style} {rig} {ref_lock} "
        f"{pose_text} {ents[first]['name']} is mid-sentence with the mouth open; every other character has a closed mouth."
        f"{spikes} No subtitles, no captions, no text, no speech bubbles."
    )

    # ---------- video prompt ----------
    dialogue = " ".join(
        f'At {t}s {ents[l["who"]]["name"]} ({pos_for(l["who"], main, [])}), {l.get("tone", "neutral")}, says: "{l["say"]}"'
        for t, l in zip(times, lines)
    )
    cont = "Continue directly from the final frame of the previous clip. " if idx > 1 else ""
    spikes_v = " " + read("spikes.txt") if clip.get("spikes") else ""
    end = clip.get("end_frame", "End on a medium two-shot with the same positions.")

    assignments = "; ".join(
        f'Line {i} at {t}s is spoken only by {ents[l["who"]]["name"]} ({pos_for(l["who"], main, [])}, {ents[l["who"]]["voice"]}): "{l["say"]}"'
        for i, (t, l) in enumerate(zip(times, lines), 1)
    ) + "."
    speakers = {l["who"] for l in lines}
    silent = [ents[k]["name"] for k in present if k not in speakers]
    silent_rule = (
        "While others speak, every non-speaking character keeps a closed mouth and reacts only with eyes and body."
        if not silent
        else f"{' and '.join(silent)} never speak{'s' if len(silent) == 1 else ''} in this clip and keep a closed mouth throughout."
    )
    positions = " ".join(
        f"{ents[k]['name']} is always on the {pos_for(k, main, [])} of the frame." for k in present
    )
    closing = read("closing_block.txt").format(
        assignments=assignments, silent_rule=silent_rule, language=language, positions=positions
    )

    video_prompt = (
        f"{style} {rig} {ref_lock} {chars} {cont}"
        f"Action: {clip['action']}{spikes_v} "
        f"Dialogue, spoken in {language}, short and clear, with timing: {dialogue} "
        f"{end} {closing}"
    )
    return image_prompt, video_prompt


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("episode")
    ap.add_argument("-o", "--out")
    args = ap.parse_args()

    ep = json.loads(Path(args.episode).read_text(encoding="utf-8"))
    ents = load_entities()
    warnings = []
    out = [f"# {ep.get('title', 'Episode')}", ""]
    if ep.get("logic"):
        out += [f"**Argument logic:** {ep['logic']}", ""]
    for i, clip in enumerate(ep["clips"], 1):
        img, vid = build_clip(ep, ents, clip, i, warnings)
        t0 = (i - 1) * 8
        out += [
            f"## Clip {i} ({t0}-{t0 + 8}s)",
            "",
            f"**Image prompt (keyframe for Clip {i}):**",
            "```",
            img,
            "```",
            "",
            f"**Video prompt (Clip {i}):**",
            "```",
            vid,
            "```",
            "",
        ]
    if warnings:
        out += ["## Checks", ""] + [f"- {w}" for w in warnings] + [""]
    text = "\n".join(out)
    if args.out:
        Path(args.out).write_text(text, encoding="utf-8")
        print(f"Wrote {args.out}", file=sys.stderr)
    else:
        print(text)
    for w in warnings:
        print("WARNING:", w, file=sys.stderr)


if __name__ == "__main__":
    main()
