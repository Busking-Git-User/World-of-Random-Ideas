---
name: angry-entities-flow-video
description: Creates 9:16 "arguing entities" short-video packages for Google Flow (Veo). Talking products, foods or objects (kape vs tsokolate, water vs cola, any "X vs Y") argue in meaningful Tagalog, with one keyframe image prompt and one 8-second video prompt per clip, a locked glossy 3D style that matches the user's reference video, no captions, and a closing block that stops Flow from giving lines to the wrong character. Use whenever the user wants entities arguing or fighting, a script or prompts for Google Flow or Veo, 8-second clip prompts, error-free or Flow-friendly dialogue, or a picture for every scene, even if they only name two things that could argue.
---

# Angry Entities Flow Video

Turns two or three named entities into a short argument video that Google Flow can generate without mixing up who says what. Output per clip: one image prompt (keyframe) and one video prompt (8 seconds, 9:16).

All editable settings live in `data/`. Do not hardcode looks or voices in your answers; read them from those files.

## Files

- `data/style_lock.txt`, `data/rig.txt`, `data/default_setting.txt`, `data/spikes.txt`: the locked visual style, copied from the user's reference video (Water vs Cola). Never change, paraphrase, or "improve" these unless the user edits the files or explicitly asks for a new style.
- `data/entities.json`: look, voice, true strengths and true flaws for each entity. Source of truth for appearance and voice.
- `data/reference_lock.txt`: the reference image lock, placed in every image and video prompt.
- `data/closing_block.txt`: the anti-error block that ends every video prompt.
- `scripts/build_prompts.py`: assembles the prompts from an episode file and runs checks.
- `references/dialogue-rules.md`: how to write dialogue that makes sense. Read it before writing any lines.
- `references/reference-style-notes.md`: what the uploaded reference shows (framing, expressions, allowed actions, dialogue feel). Update it when the user uploads a new reference.
- `references/example-episode.json` and `references/example-output.md`: a complete worked example. Match its format.

## Workflow

1. **Identify the entities and the number of scripts.** If the user named the entities, proceed without asking. Ask one short question only if you cannot tell which entities or how many scripts. Default: 1 script of 3 clips (24 seconds).
2. **Read the reference.** If the user uploaded a reference image or video of the characters, look at it first (for a video, extract a few frames with ffmpeg and view them). Follow "Reference image lock" below.
3. **Load entities.** Read `data/entities.json`. If an entity is missing, design it with the same rig (see "New entities"), add it to the JSON, and tell the user to save it in their copy.
4. **Write the argument logic first** (one sentence), then the dialogue, following `references/dialogue-rules.md`. Every line must answer the line before it.
5. **Build the episode file** (see `references/example-episode.json`) and run:
   `python scripts/build_prompts.py episode.json`
   Fix any warnings it prints (long lines, bad punctuation) and rerun. If you cannot run Python, compose the prompts by hand using the exact text from the `data/` files and the same prompt order.
6. **Deliver** the prompts in code blocks, in clip order, image prompt then video prompt. Add the short usage notes below. Do not add captions, subtitle text, hashtags, or a post package unless the user asks.

## Hard rules

- **9:16, same appearance, always.** Every image and video prompt carries the full style lock, rig, and each entity's `look` text word for word. Never vary them between clips or scripts.
- **No captions.** No subtitles, no on-screen text, no speech bubbles, no music, in the prompts and in your answer. Dialogue exists only as spoken audio. Do not output a captions section.
- **A picture for every scene.** Each clip gets a keyframe image prompt. If the user asks for a picture per line or per beat, make one per beat instead. If an image-generation tool exists in the current session, call it with the image prompt. If not, say plainly that you can't render images here and give the paste-ready image prompt. Never substitute flat vector or SVG drawings for the 3D look unless the user asks for a rough storyboard.
- **Right line, right character.** Each line is labeled with one speaker, that speaker's side of the frame, and that speaker's voice. Only the speaker's mouth moves. Entity A is always on the left, entity B always on the right, and a third entity enters at center front. Never swap sides between clips.
- **Closing block always last.** Every video prompt ends with the closing block from `data/closing_block.txt`, filled in with that clip's lines. Nothing comes after it.
- **Flow-friendly dialogue.** Max 2 lines per 8-second clip (3 only for very short lines), max 9 words per line, plain words, spelled-out numbers, no "?!", no ALL CAPS, no ellipses, no double quotes inside a line, no emojis. Timings: 0.5s and 4.0s for two lines, 0.5s, 3.0s and 5.5s for three.
- **Language.** Spoken Tagalog by default. Use Taglish only if the user asks. Keep the prompt instructions in English.
- **Continuity.** From Clip 2 on, the video prompt says to continue from the previous clip's final frame. Tell the user to use Flow's Frames to Video: last frame of Clip N becomes the first frame of Clip N+1, and the Clip N keyframe image is the first frame of Clip N.

## Reference image lock

The uploaded reference image (or video frame) is the exact design of the moving, talking characters. It overrides everything else in this skill about appearance.

- **Never change the appearance.** Shape, colors, materials, markings, face, eyes, eyebrows, eyelid shading, arms, gloves and feet stay identical to the reference in every image and video prompt. No redesign, recolor, restyle, resize or accessories, and nothing "improved".
- **Describe only what is visible.** If the reference differs from `data/entities.json`, the reference wins. Update that entity's `look` to match what you see and tell the user to save the change. For an entity that is not in the reference, use the same rig and style.
- **Actions must come from the reference.** Use the gestures, expressions, framing and setting shown in the reference or listed in `references/reference-style-notes.md`. Do not invent new body parts, props, costumes, movement across the scene or camera tricks the reference does not show. Fill the episode file's `reference_notes` field with the key visible details so they appear in every prompt.
- **Dialogue must fit the reference.** Match its feel: short, direct, sassy comebacks that hit a real flaw or brag about a real strength of the entity shown. A line must never describe something the character cannot be or do in the reference (for example, a plastic bottle cannot say it is hot).
- **Every prompt carries the lock.** The text in `data/reference_lock.txt` is in every image and video prompt, and the user is reminded to attach the reference image in Flow for every clip.

## Notes to give the user with the prompts (keep to 3 or 4 lines)

- Attach the reference image as the style and character reference in every clip, and use the clip's keyframe image as its first frame.
- Generate clips one at a time and check who speaks each line. If a line lands on the wrong character, regenerate that clip rather than editing the prompt.
- Add no subtitles in editing unless they want them.

## New entities

Reuse the shared rig (huge round white eyes, colored eyelid shading, thick black eyebrows, black noodle arms, white gloves, white sneaker feet). A new entity needs: product shape and material, one signature feature, a unique eyelid-shading color, a voice (pitch, attitude, gender feel), 3 personality words, and real strengths and flaws that people recognize. Keep the look to one sentence so it can be repeated word for word.

## Final check before sending

1. Does every line reply to the one before it and use a true strength or flaw from the entity file?
2. Is every line attributed to the right entity, with the right side and voice?
3. Does every video prompt end with the closing block?
4. Does every clip have an image prompt?
5. Is there any caption, subtitle, or on-screen text in the output? Remove it.
6. Does every prompt carry the reference image lock, and do the actions and dialogue match what the reference shows?
